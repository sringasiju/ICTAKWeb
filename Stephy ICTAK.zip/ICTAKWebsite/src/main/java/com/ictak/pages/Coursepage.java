package com.ictak.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Coursepage {

	WebDriver driver;
	@FindBy(xpath="//a[@id='dropdownMenuBlocks']")
	private WebElement course;
	@FindBy(xpath="//*[@id=\"navigation\"]/ul/li[3]/ul/div[1]/li[2]/a/div/div")
	private WebElement ctesting;
	@FindBy(xpath="//button[@data-bs-target='#exampleModalSignup' and @type='button']")
	private WebElement apply;
	@FindBy(xpath="//input[@type='text' and @placeholder='Name']")
	private WebElement Name;
	@FindBy(xpath="//input[@type='email' and @placeholder='Email']")
	private WebElement email;
	@FindBy(xpath="//input[@type='text' and @placeholder='Number']")
	private WebElement number;
	@FindBy(xpath="//button[@type='submit' and @class='btn bg-gradient-primary w-100 mt-4 mb-0']")
	private WebElement applyclick;
	
	public  Coursepage(WebDriver driver)
	{
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setcourse()
	{
		course.click();
		
	}
	public void droptesting()
	{
		ctesting.click();
	}
	public void applytesting()
	{
		apply.click();
	}
	
	public void formtest(String name,String mailid,String mobno)
	{
		Name.sendKeys(name);
		email.sendKeys(mailid);
		number.sendKeys(mobno);
		applyclick.click();
		driver.switchTo().alert().accept();
		
	}
	
	

}
