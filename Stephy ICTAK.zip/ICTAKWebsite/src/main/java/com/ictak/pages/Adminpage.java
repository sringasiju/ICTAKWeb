package com.ictak.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Adminpage {

	WebDriver driver;
	@FindBy(xpath="//a[@class='btn btn-sm bg-gradient-info mb-0 me-1 mt-2 mt-md-0']")
	private WebElement logintab;
	
	@FindBy(xpath="//a[@data-bs-target='#exampleModalForm']")
	private WebElement log;
	@FindBy(xpath="//input[@placeholder='Enter Your Email']")
	private WebElement adminlogemail;
	@FindBy(xpath="//input[@name='password']")
	private WebElement adminlogpasswrd;
	@FindBy(xpath="//button[@type='submit']")
	private WebElement signin;
	@FindBy(xpath="//button[@class='btn bg-gradient-info mt-4 mb-0']")
	private WebElement admnsignin;
	@FindBy(xpath="//a[@class='opacity-5 text-dark']")
	private WebElement heading;
	@FindBy(xpath="//a[@routerlink='/adminpage/registered-users']")
	private WebElement admindashboard;
	@FindBy(xpath="//button[@class='btn bg-gradient-primary btn-sm mb-0'and @target='_blank']")
	private WebElement download;
	
		
	public Adminpage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public boolean loginhometab()
	{
		return logintab.getText().toString().contains("LOGIN");
	}
	
	
	public void setlogin()
	{
		
		log.click();
		
	}
	public void invalidlog(String uname,String pswd)
	{
		adminlogemail.sendKeys(uname);
		adminlogpasswrd.sendKeys(pswd);
		signin.click();
		driver.navigate().refresh();
	}
	
	
	public void adminlogintest(String username,String password)
	{
		log.click();
		adminlogemail.sendKeys(username);
		adminlogpasswrd.sendKeys(password);
		//driver.switchTo().alert().accept();
		admnsignin.click();

	}
	
	public boolean admindashboard()
	{		

		return heading.getText().toString().contains("Admin Dashboard");
	}
	public void dashboard()
	{
		
		
		admindashboard.click();
		download.click();

	}
	
	
	}




