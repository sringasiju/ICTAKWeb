package com.ictak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
	WebDriver driver;
	private By Home=By.xpath("//h1[text()='ICT Academy of Kerala']");
	@FindBy(xpath="//a[@routerlink='/LandingPage/about']")
	private WebElement aboutus;
		
	public Homepage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);		
	}
	public String getTextHome() 
	{

	return driver.findElement(Home).getText();
	
	}
	
	
	
	public void  clicktabs()
	{
		
		aboutus.click();
		
		
	}

}
