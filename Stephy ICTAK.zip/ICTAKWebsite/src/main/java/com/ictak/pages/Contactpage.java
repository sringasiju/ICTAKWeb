package com.ictak.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Contactpage {
	WebDriver driver;
	@FindBy(xpath="//a[@routerlink='/LandingPage/contactus']")
	private WebElement contactheading;
	
	@FindBy(xpath="//a[@id='dropdownMenuPages' and @routerlink='/LandingPage/contactus' ]")
	private WebElement cont;
	@FindBy(xpath="//input[@name='name' and @placeholder='Full Name']")
	private WebElement name;
	@FindBy(xpath="//input[@type='email']")
	private WebElement mail;
	@FindBy(xpath="//input[@name='coursename' and @type='text']")
	private WebElement msg;
	@FindBy(xpath="//input[@name='subject' and @id='message']")
	private WebElement messages;
	@FindBy(xpath="//button[@type='submit' and @class='btn btn-round bg-gradient-info mb-0']")
	private WebElement sendmsg;
	
	public Contactpage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	public boolean contactvalidation()
	{
		return contactheading.getText().toString().contains("Contact Us");

	}
	public void setcontact()
	{
		cont.click();
		
	}
	public void setfullname(String Name )
	{
		name.sendKeys(Name);
	}
	public void setemailid(String mailid)
	{
		mail.sendKeys(mailid);
	}
	public void setmessage(String msgs)
	{
		msg.sendKeys(msgs);
	}
	public void setmsgs(String emsgs)
	{
		messages.sendKeys(emsgs);
	}
	public void setfinal()
	{
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		Actions actions = new Actions(driver);
		actions.moveToElement(sendmsg).click().perform();
		driver.switchTo().alert().accept();
		
	}

}
