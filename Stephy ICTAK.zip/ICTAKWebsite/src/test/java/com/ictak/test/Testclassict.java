package com.ictak.test;


import java.awt.AWTException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ictak.pages.Adminpage;
import com.ictak.pages.Contactpage;
import com.ictak.pages.Coursepage;
import com.ictak.pages.Homepage;

public class Testclassict extends Baseclassictak {
	Homepage homeobj;
	Coursepage cobj;
	Contactpage contobj;
	Adminpage loginobj;
	
	@Test
	public void demo()
	{
		homeobj=new Homepage(driver);
		String Text=homeobj.getTextHome();
		homeobj.clicktabs();	


	}
	
	
	@Test
	public void tc_2() throws AWTException {
		cobj=new Coursepage(driver);
		contobj.contactvalidation();
		cobj.setcourse();
		cobj.droptesting();
		cobj.applytesting();
		cobj.formtest("stephy","stephy@gmail.com","894555");
		
     }
	@Test
     public void tc_3() 
          {
		loginobj=new Adminpage(driver);
		Assert.assertTrue(loginobj.loginhometab());
		loginobj.setlogin();
		loginobj.invalidlog(" ", " ");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		loginobj.adminlogintest("superadmin","12345");
		Assert.assertTrue(loginobj.admindashboard());
		loginobj.dashboard();

	    }
	@Test
	public void tc_12()
	{
		contobj=new Contactpage(driver);
		contobj.setcontact();
		contobj.setfullname("STEPHY ");
		contobj.setemailid("stephy@gmail.com");
		contobj.setmessage("software testing");
		contobj.setmsgs("Register");
		contobj.setfinal();
				
	}
	

	

}
