package com.ictak.test;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class Baseclassictak {
	

	WebDriver driver;
	@BeforeTest
	public void check()
	{
		driver=new ChromeDriver();
		driver.get("http://64.227.132.109/LandingPage");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.manage().window().maximize();
		
	}
}
