package com.ictak.pages;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass extends BaseClass {

	
	
	HomePage hobj;
	ContactUs cobj;
	Login lobj;
	@Test(priority=1)
	public void validate() throws InterruptedException {
		hobj=new HomePage(driver);
		hobj.Home();
		String text=driver.getTitle();
		String exptxt="ICT Academy of Kerala";
		Assert.assertEquals(text, exptxt);
		System.out.println(text);
		
	}
	@Test(priority=2)
	public void contactUs() {// throws InterruptedException {
		cobj= new ContactUs(driver);
		cobj.sendMessage("Arathi", "arathi236@gmail.com", "ST", "FullTime");
	}
	@Test(priority=3)
	public void login() {//throws InterruptedException {
		lobj=new Login(driver);
		lobj.inputmessage("superadmin", "1357");
		
	}
	@Test(priority=4)
	public void positivelogin() {//throws InterruptedException {
		driver.navigate().refresh();
		lobj=new Login(driver);
		lobj.inputmessage("superadmin", "12345");
		Assert.assertTrue(lobj.adminDashboard());
	}
	
}
