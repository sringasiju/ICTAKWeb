package com.ictak.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactUs {

	
	public ContactUs(WebDriver driver2) {
		// TODO Auto-generated constructor stub
		this.driver=driver2;
		PageFactory.initElements(driver2, this);
	}
	WebDriver driver;
	@FindBy(xpath="//i[text()='mail']")
	private WebElement ContactUs;
	@FindBy (xpath="//input[@placeholder='Full Name']")
	private WebElement name;
	@FindBy (xpath="//input[@placeholder='Email id']")
	private WebElement emailid;
	@FindBy (xpath="//input[@name='coursename']")
	private WebElement coursename;
	@FindBy (xpath="//input[@id='message']")
	private WebElement message;
	@FindBy (xpath="//button[text()='Send Message']")
	private WebElement sendmessage;
	
	public void sendMessage(String n,String mail,String cname,String msg)  {
		ContactUs.click();
		name.sendKeys(n);
		
		emailid.sendKeys(mail);
		
		coursename.sendKeys(cname);
	
		message.sendKeys(msg);
		
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",sendmessage);
	
		driver.switchTo().alert().accept();
		
	}
}

	
