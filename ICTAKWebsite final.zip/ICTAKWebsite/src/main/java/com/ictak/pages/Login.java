package com.ictak.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {

	
		public Login(WebDriver driver2) {
		// TODO Auto-generated constructor stub
			this.driver=driver2;
			PageFactory.initElements(driver2, this);
	}
		WebDriver driver;
		@FindBy(xpath="//i[text()='fingerprint']")
		private WebElement Login;
		@FindBy(xpath="//input[@name='email']")
		private WebElement email;
		@FindBy(xpath="//input[@name='password']")
		private WebElement password;
		@FindBy(xpath="//button[@type='submit']")
		private WebElement signin;
		@FindBy(xpath="//h4[text()='Dashboard']")
		private WebElement dashboard;
		
		
		public void inputmessage(String mailid,String pword) {// throws InterruptedException {
		Login.click();
		email.sendKeys(mailid);
		password.sendKeys(pword);
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",signin);
		//Thread.sleep(8000);
		
		 }
		public boolean adminDashboard() {
			
			return dashboard.getText().toString().contains("Dashboard");
			
		}
		 
}
       
