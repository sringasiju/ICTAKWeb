package com.ictak.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	
WebDriver driver;

	@FindBy(xpath="//i[text()='cottage']")
	private WebElement home;
	@FindBy(xpath="//i[text()='offline_bolt']")
	private WebElement AboutUs ;
	@FindBy(xpath="//i[text()='class']")
	private WebElement Courses;
	@FindBy(xpath="//i[text()='group']")
	private WebElement Membership ;
	@FindBy(xpath="//i[text()='flag_circle']")
	private WebElement Events;
	
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		
	}
	public void Home()  {
		home.click();
		
		AboutUs.click();
		
		Courses.click();
		
		Membership.click();
		
		Events.click();
	}
	
	
}
