package org.ictkerala.ictakwebsite;

import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminLogin {
	WebDriver driver;
	@FindBy(xpath = "//a[@class='btn btn-sm bg-gradient-info mb-0 me-1 mt-2 mt-md-0']")
	private WebElement login;
	@FindBy (xpath ="//input[@type='text' and @placeholder='Enter Your Email' and @name='email' and @required and contains(@class, 'form-control') and contains(@class, 'ng-pristine') and contains(@class, 'ng-invalid') and contains(@class, 'ng-touched')]")
	private WebElement adminloginEmail;
	@FindBy (xpath = "//input[@type='password' and @name='password' and @placeholder='•••••••••••••' and @required and not(@autocomplete) and contains(@class, 'form-control') and contains(@class, 'ng-pristine') and contains(@class, 'ng-invalid') and contains(@class, 'ng-touched')]")
	private WebElement adminloginPassword; 
	@FindBy (xpath ="//button[@type='submit' and @class='btn bg-gradient-info mt-4 mb-0' and @disabled]")
	//button[@type='submit' and @class='btn bg-gradient-info mt-4 mb-0']
	private WebElement signin;
	@FindBy(xpath = "//h4[@class='font-weight-bolder mb-0'")
	private WebElement heading;
	@FindBy(xpath ="//a[@routerlink='/adminpage/academic' and @class='nav-link text-white']")
	private WebElement academicmembership;
	@FindBy(xpath ="//a[@routerlink='/adminpage/corporate' and @class='nav-link text-white']")
	private WebElement corporatemembership;
	@FindBy(xpath = "//button[@class='btn bg-gradient-primary btn-sm mb-0']")
	private WebElement download;

	public AdminLogin (WebDriver driver) {
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	public void setlogin() {
		login.click();
		
	}
	public void invalidLogin(String uname,String pwd) {
		adminloginEmail.sendKeys(uname);
		adminloginPassword.sendKeys(pwd);
		signin.click();
		driver.navigate().refresh();
		
	}
	public void adminlogintest(String username,String password)throws ElementClickInterceptedException {
		login.click();
		adminloginEmail.sendKeys(username);
		adminloginPassword.sendKeys(password);
		signin.click();
		
	}
	public boolean admindashboard() {
		
		return heading.getText().toString().contains("Admin Dashboard");
	}
	
	public void dashboard() {
		
		academicmembership.click();
		download.click();
		corporatemembership.click();
		download.click();
	}

}
