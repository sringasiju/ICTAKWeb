package org.ictkerala.ictakwebsite;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class CorporateMembership {

	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"dropdownMenuDocs\"]")
	private WebElement membership;
	@FindBy (xpath ="//a[@routerlink='/LandingPage/corporate' and @class='dropdown-item py-2 ps-3 border-radius-md']")
	private WebElement corporatemembership;
	@FindBy(xpath = "//button[@type='submit' and @routerlink='/LandingPage/corporateform']")
	private WebElement registerhere;
	@FindBy(xpath = "//button[@type='submit' and @routerlink='/LandingPage/corporateform']")
	private WebElement corporateHead;
	
	@FindBy(xpath = "//input[@type='text' and @name='name' and @class='form-control ng-pristine ng-invalid ng-touched']")
	private WebElement name;
	@FindBy(xpath = "//input[@type='text' and @name='address' and @class='form-control ng-pristine ng-invalid ng-touched']")
	private WebElement address;
	@FindBy(xpath = "//input[@type='text' and @class='form-control ng-pristine ng-invalid ng-touched']")
	private WebElement headOftheOrganization;
	@FindBy(xpath = "//input[@type='text' and @name='nature']")
	private WebElement natureofOrganization;
	@FindBy(xpath = "//input[@type='text' and placeholder value formcontrolname='email']")
	private WebElement email;
	@FindBy(xpath = "//input[@type='submit' and @value='REGISTER' and contains(@class, 'btn') and contains(@class, 'btn-info') and contains(@class, 'w-100')]")
	private WebElement register;
	
	public CorporateMembership(WebDriver driver) {
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	public void setMembership() {
		membership.click();
		
	}

	public void selectCorporateMembership() {
		
		corporatemembership.click(); 
		
	}
	public void registeration() {
		
		registerhere.click();
	
	}
	public boolean getCorporateHead() {
		System.out.println("Corporate Membership Form");
		return corporateHead.getText().contains("Corporate Membership Form");
		
		
	}
	public void corporatemembershipforms(String corporatename,String corporateaddress,String corporatehead,String natureOfOrganization,String mailid) {
		
		name.sendKeys(corporatename);
		address.sendKeys(corporateaddress);
		headOftheOrganization.sendKeys(corporatehead);
		natureofOrganization.sendKeys(natureOfOrganization);
		email.sendKeys(mailid);
		
		register.click();	
		WebElement element = driver.findElement(By.xpath("//input[@type='submit' and @value='REGISTER' and contains(@class, 'btn') and contains(@class, 'btn-info') and contains(@class, 'w-100')]"));
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().perform();
		Alert alert =driver.switchTo().alert();
		System.out.println(alert.getText());
		
	}
public void invalidCoporatemembershipForm(String corporatename,String corporateaddress,String corporatehead,String natureOfOrganization,String mailid) {
		
		name.sendKeys(corporatename);
		address.sendKeys(corporateaddress);
		headOftheOrganization.sendKeys(corporatehead);
		natureofOrganization.sendKeys(natureOfOrganization);
		email.sendKeys(mailid);
		
		register.click();	
		WebElement element = driver.findElement(By.xpath("//input[@type='submit' and @value='REGISTER' and contains(@class, 'btn') and contains(@class, 'btn-info') and contains(@class, 'w-100')]"));
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().perform();
		Alert alert =driver.switchTo().alert();
		System.out.println(alert.getText());
		driver.navigate().refresh();
		
	}
	public void invalidEmail(String mail) {
		email.sendKeys(mail);
		register.click();
		driver.navigate().refresh();
		
	}
    public void returnToHomePage(WebDriver driver) {
    
        driver.get("http://64.227.132.109/LandingPage/");
    }

}
