package org.ictkerala.ictakwebsite;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AcademicMembership {
	
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"dropdownMenuDocs\"]")
	private WebElement membership;
	@FindBy (xpath ="//ul/li[1]//a[@href='/LandingPage/academic']")
	private WebElement academicmembership;
	@FindBy (xpath ="//h1[@class='text-light aos-init aos-animate' and @data-aos='flip-up' and @data-aos-duration='2000' and text()='PREMIUM MEMBERSHIP FORM']")
	private WebElement academicFormHead;
	
	@FindBy (xpath ="//a[@routerlink='/LandingPage/academiccollaboarations' and @class='btn btn-warning' and text()='Registration Closed']")
	private WebElement registerationclosed;

	public AcademicMembership(WebDriver driver) {
		this.driver =driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setMembership() {
		membership.click();
		  
	} 
	public void selectAcademicMembership() {
		academicmembership.click(); 
		
	}
	public void clickOnViewMembersbtn()throws ElementClickInterceptedException {
		 
		WebElement element = driver.findElement(By.xpath("//a[@class='btn btn-info' and @routerlink='/LandingPage/academiccollaboarations']"));
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().perform();
		
	}
	public boolean getAcadmicPremiumHead() {
		System.out.println("PREMIUM MEMBERSHIP FORM");
		return academicFormHead.getText().contains("PREMIUM MEMBERSHIP FORM");
		
		
	}
	public boolean clickOnRegisterationClosed() {
		System.out.println("Registration Closed");
		return registerationclosed.getText().contains("Registration Closed");
		
	}
	public void returnToHomePage(WebDriver driver) {
		    
	    driver.get("http://64.227.132.109/LandingPage/");
	}
	
}
