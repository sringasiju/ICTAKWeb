 package org.ictkerala.ictakwebsite;


import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.PageFactory;

public class Homepage {
	WebDriver driver;

	public Homepage(WebDriver driver2) {
		this.driver =driver2;
		PageFactory.initElements(driver2,this);
	}



}
