package org.ictkerala.test_ictakpages;

import java.time.Duration;

import org.ictkerala.ictakwebsite.AcademicMembership;
import org.ictkerala.ictakwebsite.AdminLogin;
import org.ictkerala.ictakwebsite.CorporateMembership;
import org.ictkerala.ictakwebsite.Homepage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass extends BaseClass {
	Homepage home;
	AcademicMembership academic;
	CorporateMembership corporate;
	AdminLogin admin;
	
	@Test(priority = 1)
	public void homepage(){
		home = new Homepage(driver);
		String pagetitle= driver.getTitle();
		System.out.println("ICTAK :"+pagetitle);

	}
	@Test(priority = 2)
	public void academicMembership() {
		academic = new AcademicMembership(driver);
		academic.setMembership();
		academic.selectAcademicMembership();
		academic.clickOnViewMembersbtn();
		Assert.assertTrue(academic.getAcadmicPremiumHead());
		academic.clickOnRegisterationClosed();
		Assert.assertFalse(academic.clickOnRegisterationClosed());
		academic.returnToHomePage(driver);
	}  
	
	@Test(priority = 3)
	public void corporateMembership() {
		corporate = new CorporateMembership(driver);
		corporate.setMembership();
		corporate.selectCorporateMembership();
		corporate.registeration();
		Assert.assertTrue(corporate.getCorporateHead());
		corporate.corporatemembershipforms("Angel","mattathil","Trivandrum","computer Applications","anjuzzmail.com");
		corporate.invalidCoporatemembershipForm("", "", "", "", "");
		Assert.assertFalse(false,"Invalid Form Fields");
		corporate.invalidEmail("abcfh");
		Assert.assertFalse(false,"Invalid Email");
		corporate.returnToHomePage(driver);
	}
	@Test(priority = 4)
	public void adminLogin() {
		admin = new AdminLogin(driver);
		admin.setlogin();
		admin.invalidLogin("", "");
		Assert.assertFalse(false,"Invalid Login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		admin.adminlogintest("superadmin","12345");
		Assert.assertTrue(admin.admindashboard());
		admin.dashboard();
	}
}